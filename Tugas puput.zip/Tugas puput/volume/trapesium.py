def volume_trapesium(alas_atas, alas_bawah, tinggi):
    luas_alas = (alas_atas + alas_bawah) / 2
    volume = luas_alas * tinggi
    return volume
